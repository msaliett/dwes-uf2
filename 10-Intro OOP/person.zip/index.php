<?php
require "Person.php";
$mike = new Person("Mike", 20);
echo $mike;